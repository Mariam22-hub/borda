#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <cmath>

using namespace std;

struct Measurement {
    double x, y, rotz, azimuth;
};

struct Position {
    double x, y, err;
};

// convert degrees to radians.
double degreesToRadians(double degrees) {
    return (degrees * M_PI / 180.0);
}

// Parse a single measurement from a string.
Measurement parseMeasurement(const string& data) {
    Measurement m;
    stringstream ss(data);
    char comma;
    ss >> m.x >> comma >> m.y >> comma >> m.rotz >> comma >> m.azimuth;
    m.rotz = degreesToRadians(m.rotz);
    m.azimuth = degreesToRadians(m.azimuth);
    return m;
}

// Function to estimate the position of the tag given measurements using ( least squares ).
Position estimatePosition(const vector<Measurement>& measurements) {
    size_t n = measurements.size();
    double sum_x = 0, sum_y = 0, sum_xx = 0, sum_xy = 0, sum_yy = 0;
    double sum_azimuth_x = 0, sum_azimuth_y = 0;

    for (const auto& m : measurements) {
        double azimuth = m.azimuth + m.rotz; // Adjusted for locator's rotation.
        double cos_azimuth = cos(azimuth);
        double sin_azimuth = sin(azimuth);

        sum_x += m.x;
        sum_y += m.y;
        
        sum_xx += m.x * m.x;
        sum_xy += m.x * m.y;
        sum_yy += m.y * m.y;
        
        sum_azimuth_x += cos_azimuth * m.x;
        sum_azimuth_y += sin_azimuth * m.y;
    }

    // Calculate the least squares solution (x, y).
    double denom = n * (sum_xx + sum_yy) - (sum_x * sum_x + sum_y * sum_y);
    
    if (abs(denom) < 1e-6) {
        return {0, 0, -1}; // Denominator is too small; no unique solution.
    }

    double x = (sum_azimuth_x * (sum_yy * n - sum_y * sum_y) + sum_azimuth_y * (sum_xy * n - sum_x * sum_y)) / denom;
    double y = (sum_azimuth_y * (sum_xx * n - sum_x * sum_x) + sum_azimuth_x * (sum_xy * n - sum_x * sum_y)) / denom;

    // Calculate the residual sum of squares as error.
    double err = 0;
    for (const auto& m : measurements) {
        
        double predicted_azimuth = atan2(y - m.y, x - m.x) - m.rotz;
        double diff_azimuth = m.azimuth - predicted_azimuth;
       
        // Normalize the angle difference to [-pi, pi].
        diff_azimuth = atan2(sin(diff_azimuth), cos(diff_azimuth));
        err += diff_azimuth * diff_azimuth;
    }

    return {x, y, sqrt(err / n)};
}


// BEFORE RUNNING, MAKE SURE TO CHANGE THE RUN CONFIGURATION TO EXECUTE THE RIGHT PROBLEM -> (problem 2)
int main() {
    cout << "In problem 2" << endl;

    ifstream inputFile("input_q2.txt");
    ofstream outputFile("output_q2.txt");
    string line;

    while (getline(inputFile, line)) {
        stringstream ss(line);
        string measurementString;
        vector<Measurement> measurements;

        while (getline(ss, measurementString, ';')) {
            measurements.push_back(parseMeasurement(measurementString));
        }

        if (measurements.size() < 2) {
            outputFile << "fail, not enough data" << endl;
            continue;
        }

        Position estimatedPosition = estimatePosition(measurements);

        if (estimatedPosition.err < 0) {
            outputFile << "fail, estimation impossible" << endl;
        } else {
            outputFile << estimatedPosition.x << ","
                       << estimatedPosition.y << ","
                       << estimatedPosition.err << endl;
        }
    }

    cout << "Done" << endl;

    inputFile.close();
    outputFile.close();

    return 0;
}

